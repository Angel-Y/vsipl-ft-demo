#ifndef __VI_FFTTYPE_H_
#define __VI_FFTTYPE_H_

typedef enum {
        VSIP_CCFFTOP,
        VSIP_CCFFTIP,
        VSIP_RCFFTOP,
        VSIP_CRFFTOP
        } vsip_ffttype;

#endif
